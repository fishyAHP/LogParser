package index

import (
	"errors"
	"fmt"

	"fishyAHP/LogParser.git/internal/core/domain"
	"fishyAHP/LogParser.git/internal/features/index/hash"
	"fishyAHP/LogParser.git/internal/features/index/text"
)

var (
	ErrInvalidValueType  = errors.New("invalid value type")
	ErrInvalidStringHash = fmt.Errorf(
		"%w: string hash index expects StringValue",
		ErrInvalidValueType,
	)
	ErrInvalidIntHash = fmt.Errorf(
		"%w int hash index expects IntValue",
		ErrInvalidValueType,
	)
	ErrInvalidFloatHash = fmt.Errorf(
		"%w: float hash index expects FloatValue",
		ErrInvalidValueType,
	)
	ErrInvalidBoolHash = fmt.Errorf(
		"%w: bool hash index expects BoolValue",
		ErrInvalidValueType,
	)

	ErrInvalidText = fmt.Errorf(
		"%w: text index expects StringType",
		ErrInvalidValueType,
	)
)

type stringHashIndex struct {
	index *hash.Index[domain.StringValue]
}

type intHashIndex struct {
	index *hash.Index[domain.IntValue]
}

type floatHashIndex struct {
	index *hash.Index[domain.FloatValue]
}

type boolHashIndex struct {
	index *hash.Index[domain.BoolValue]
}

type textIndex struct {
	index *text.Index
}

var (
	_ FieldIndex = (*stringHashIndex)(nil)
	_ FieldIndex = (*intHashIndex)(nil)
	_ FieldIndex = (*floatHashIndex)(nil)
	_ FieldIndex = (*boolHashIndex)(nil)

	_ FieldIndex = (*textIndex)(nil)
)

func newHashIndex(field domain.Field) (FieldIndex, error) {
	switch field.FieldType {
	case domain.StringType:
		return &stringHashIndex{
			index: hash.New[domain.StringValue](),
		}, nil
	case domain.BoolType:
		return &boolHashIndex{
			index: hash.New[domain.BoolValue](),
		}, nil
	case domain.IntType:
		return &intHashIndex{
			index: hash.New[domain.IntValue](),
		}, nil
	case domain.FloatType:
		return &floatHashIndex{
			index: hash.New[domain.FloatValue](),
		}, nil
	default:
		return nil, fmt.Errorf(
			"hash index doesnt support %v type",
			field.FieldType,
		)
	}
}

func newTextIndex(field domain.Field) (FieldIndex, error) {
	switch field.FieldType {
	case domain.StringType:
		return &textIndex{
			index: text.New(),
		}, nil
	default:
		return nil, fmt.Errorf(
			"text index doesn't support %v type",
			field.FieldType)
	}
}

func (sh *stringHashIndex) Indexer() Index {
	return sh.index
}

func (b boolHashIndex) Indexer() Index {
	return b.index
}

func (i *intHashIndex) Indexer() Index {
	return i.index
}

func (f *floatHashIndex) Indexer() Index {
	return f.index
}

func (t textIndex) Indexer() Index {
	return t.index
}
