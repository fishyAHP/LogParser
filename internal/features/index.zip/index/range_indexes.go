package index

import (
	"cmp"
	"fmt"
	"time"

	"fishyAHP/LogParser.git/internal/core/domain"
	"fishyAHP/LogParser.git/internal/features/index/ranged"
)

var (
	ErrInvalidTimeRange = fmt.Errorf(
		"%w: time ranged index expects TimeValue",
		ErrInvalidValueType,
	)
	ErrInvalidFloatRange = fmt.Errorf(
		"%w: float ranged index expects TimeValue",
		ErrInvalidValueType,
	)
	ErrInvalidIntRange = fmt.Errorf(
		"%w: int ranged index expects TimeValue",
		ErrInvalidValueType,
	)
)

type timeRangeIndex struct {
	index *ranged.Index[domain.TimeValue]
}

type intRangeIndex struct {
	index *ranged.Index[domain.IntValue]
}

type floatRangeIndex struct {
	index *ranged.Index[domain.FloatValue]
}

var (
	_ FieldIndex = (*timeRangeIndex)(nil)
	_ FieldIndex = (*intRangeIndex)(nil)
	_ FieldIndex = (*floatRangeIndex)(nil)
)

func (tr *timeRangeIndex) Indexer() Index {
	return tr.index
}

func (ir *intRangeIndex) Indexer() Index {
	return ir.index
}

func (fr *floatRangeIndex) Indexer() Index {
	return fr.index
}

func newRangeIndex(field domain.Field) (FieldIndex, error) {
	switch field.FieldType {
	case domain.IntType:
		return &intRangeIndex{
			index: ranged.New[domain.IntValue](cmp.Compare[domain.IntValue]),
		}, nil
	case domain.FloatType:
		return &floatRangeIndex{
			index: ranged.New[domain.FloatValue](cmp.Compare[domain.FloatValue]),
		}, nil
	case domain.TimeType:
		return &timeRangeIndex{
			index: ranged.New(
				func(k1, k2 domain.TimeValue) int {
					key1 := time.Time(k1).Truncate(time.Millisecond)
					key2 := time.Time(k2).Truncate(time.Millisecond)

					switch {
					case key1.Before(key2):
						return -1
					case key1.After(key2):
						return 1
					default:
						return 0
					}
				}),
		}, nil
	default:
		return nil, fmt.Errorf(
			"ranged index doesn't support %v type",
			field.FieldType,
		)
	}
}
